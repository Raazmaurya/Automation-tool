jQuery-Preload-CSS-Images
=========================

A solution that automates the age-old task of preloading images in web applications.
